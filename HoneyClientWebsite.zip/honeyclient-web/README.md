# HoneyClient Website

This is a fully responsive, glassmorphic landing page for HoneyClient.

## How to add your images
To make the website perfect, create a folder named `assets` in the same directory as `index.html`.

Place your two images inside the `assets` folder and rename them exactly like this:

1. **The App Icon:** Rename the image with the glowing honeycomb on the water to `app-icon.png`
2. **The Honeycomb:** Rename the transparent pixel honeycomb image to `honeycomb.png`

## Previewing the site
Just double-click `index.html` to open it in your browser. 

## Features included
- **Honey Drip:** An SVG animated drip at the top of the screen.
- **Glassmorphic Buttons:** The "Coming Soon" button has a frosted glass effect with a light shine animation.
- **Glowing Icon:** The app icon has a pulsing amber glow behind it.
- **Parallax Effect:** Move your mouse around, and the app icon follows slightly.
